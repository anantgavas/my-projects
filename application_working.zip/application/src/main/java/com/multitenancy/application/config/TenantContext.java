package com.multitenancy.application.config;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TenantContext {
    private static final ThreadLocal<String> CURRENT_TENANT = new ThreadLocal<>();
    private static final Logger log = LoggerFactory.getLogger(TenantContext.class);

    public static void setCurrentTenant(String tenant) {
        CURRENT_TENANT.set(tenant);
        System.out.println("Current tenant is in TenantContext :" + tenant);
    }

    public static String getCurrentTenant() {
        System.out.println("Get Current tenant is in TenantContext :" + CURRENT_TENANT.get());
        return CURRENT_TENANT.get();
    }

    public static void clear() {
        CURRENT_TENANT.remove();
    }
}
