package com.multitenancy.application.controller;


import com.multitenancy.application.entity.Customer;
import com.multitenancy.application.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping
    public List<Customer> getCustomers(@RequestHeader("X-TenantID") String tenantId) {
        return customerService.getCustomers(tenantId);
    }

    @PostMapping
    public Customer addCustomer(@RequestHeader("X-TenantID") String tenantId, @RequestBody Customer customer) {
        return customerService.addCustomer(tenantId, customer);
    }
}
