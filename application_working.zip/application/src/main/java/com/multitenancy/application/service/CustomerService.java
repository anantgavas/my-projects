package com.multitenancy.application.service;


import com.multitenancy.application.config.TenantContext;
import com.multitenancy.application.entity.Customer;
import com.multitenancy.application.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public List<Customer> getCustomers(String tenant) {
        TenantContext.setCurrentTenant(tenant);
        System.out.println("getCustomers method in service : "+ tenant);
        try {
            return customerRepository.findByTenant(tenant);
        } finally {
            TenantContext.clear();
        }
    }

    public Customer addCustomer(String tenant, Customer customer) {
        TenantContext.setCurrentTenant(tenant);
        System.out.println("inside service :" + tenant);
        try {
            customer.setTenant(tenant);
            System.out.println("customer details in service :" + customer);
            return customerRepository.save(customer);
        } finally {
            TenantContext.clear();
        }
    }
}
