package com.multitenancy.application.config;

import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Component
public class MultiTenantConnectionProviderImpl extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl {

    private final Map<String, DataSource> dataSourceMap = new HashMap<>();

    @Autowired
    public MultiTenantConnectionProviderImpl(
            @Qualifier("defaultDataSource") DataSource defaultDataSource,
            @Qualifier("tenant1DataSource") DataSource tenant1DataSource,
            @Qualifier("tenant2DataSource") DataSource tenant2DataSource) {
        dataSourceMap.put("default", defaultDataSource);
        dataSourceMap.put("tenant1", tenant1DataSource);
        dataSourceMap.put("tenant2", tenant2DataSource);
    }

    @Override
    protected DataSource selectAnyDataSource() {
        return dataSourceMap.get("default");
    }

    @Override
    protected DataSource selectDataSource(String tenantIdentifier) {
        DataSource dataSource = dataSourceMap.get(tenantIdentifier);
        return dataSource != null ? dataSource : dataSourceMap.get("default");
    }

    @Override
    public Connection getConnection(String tenantIdentifier) throws SQLException {
        String tenant = TenantContext.getCurrentTenant();
        DataSource dataSource = selectDataSource(tenant);
        if (dataSource == null) {
            throw new SQLException("Unknown tenant identifier: " + tenantIdentifier);
        }
        System.out.println("catalog====================== :" +dataSource.getConnection().getCatalog());
        return dataSource.getConnection();
    }
}