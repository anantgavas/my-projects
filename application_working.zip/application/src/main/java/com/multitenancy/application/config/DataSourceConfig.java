package com.multitenancy.application.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.password}")
    private String password;

    @Primary
    @Bean(name = "defaultDataSource")
    public DataSource defaultDataSource() {
        return DataSourceBuilder.create()
                .url("jdbc:mysql://localhost:3306/default_db")
                .username(username)
                .password(password)
                .build();
    }

    @Bean(name = "tenant1DataSource")
    public DataSource tenant1DataSource() {
        return DataSourceBuilder.create()
                .url("jdbc:mysql://localhost:3306/tenant1_db")
                .username(username)
                .password(password)
                .build();
    }

    @Bean(name = "tenant2DataSource")
    public DataSource tenant2DataSource() {
        return DataSourceBuilder.create()
                .url("jdbc:mysql://localhost:3306/tenant2_db")
                .username(username)
                .password(password)
                .build();
    }
}
