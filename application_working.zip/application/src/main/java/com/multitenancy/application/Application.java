package com.multitenancy.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.multitenancy.application.config","com.multitenancy.application.controller","com.multitenancy.application.service",
		"com.multitenancy.application.repository","com.multitenancy.application.entity"})
@EntityScan("com.multitenancy.application.entity")
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
