package com.multitenancy.mongodb.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.CollectionOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class MongoDBConfig {

    @Value("${spring.data.mongodb.uri.tenant1}")
    private String tenant1URI;

    @Value("${spring.data.mongodb.uri.tenant2}")
    private String tenant2URI;

    @Bean
    public Map<String, MongoTemplate> mongoTemplates() {
        Map<String, MongoTemplate> mongoTemplates = new HashMap<>();
        mongoTemplates.put("tenant1MongoTemplate", createMongoTemplate(tenant1URI));
        mongoTemplates.put("tenant2MongoTemplate", createMongoTemplate(tenant2URI));
        return mongoTemplates;
    }

    private MongoTemplate createMongoTemplate(String uri) {
        MongoTemplate mongoTemplate = new MongoTemplate(new SimpleMongoClientDatabaseFactory(uri));
        createCollectionsIfNotExist(mongoTemplate);
        return mongoTemplate;
    }

    private void createCollectionsIfNotExist(MongoTemplate mongoTemplate) {
        if (!mongoTemplate.collectionExists("customers")) {
            mongoTemplate.createCollection("customers", CollectionOptions.empty());
        }
        // Add more collections as needed
    }
}