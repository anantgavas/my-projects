package com.multitenancy.mongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.multitenancy.mongodb.config", "com.multitenancy.mongodb.controller", "com.multitenancy.mongodb.service",
		"com.multitenancy.mongodb.repository", "com.multitenancy.mongodb.entity"})
public class MongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongodbApplication.class, args);
	}

}
