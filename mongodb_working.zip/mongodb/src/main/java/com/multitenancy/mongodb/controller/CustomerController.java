package com.multitenancy.mongodb.controller;

import com.multitenancy.mongodb.entity.Customer;
import com.multitenancy.mongodb.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping
    public List<Customer> getAllCustomers(@RequestHeader(value = "X-TenantID", required = false) String tenantId) {
        return customerService.getAllCustomers(tenantId);
    }

    @PostMapping
    public Customer addCustomer(@RequestHeader(value = "X-TenantID", required = false) String tenantId, @RequestBody Customer customer) {
        System.out.println("tenant in controller---------- :"+tenantId);
        return customerService.addCustomer(tenantId, customer);
    }
}