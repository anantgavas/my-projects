package com.multitenancy.mongodb.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class MultiTenantMongoTemplate {

    @Autowired
    private Map<String, MongoTemplate> mongoTemplates;

    public MultiTenantMongoTemplate(Map<String, MongoTemplate> mongoTemplates) {
        this.mongoTemplates = mongoTemplates;
    }

    public MongoTemplate getMongoTemplate(String tenantId) {
        System.out.println("tenantId in getMongoTemplate----: "+tenantId);
        String key = tenantId + "MongoTemplate";
        System.out.println("Checking key in getMongoTemplate----: "+key);
        System.out.println("Key exists: "+mongoTemplates.containsKey(key));

        MongoTemplate mongoTemplate = mongoTemplates.get(key);
        System.out.println("***********mongoTemplate*********** "+mongoTemplate.getDb().getName());
        if (mongoTemplate == null) {
            throw new IllegalArgumentException("No MongoTemplate found for tenant: " + tenantId);
        }
        return mongoTemplate;
    }
}