package com.multitenancy.mongodb.service;

import com.multitenancy.mongodb.config.MultiTenantMongoTemplate;
import com.multitenancy.mongodb.config.TenantContext;
import com.multitenancy.mongodb.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private MultiTenantMongoTemplate multiTenantMongoTemplate;

    public List<Customer> getAllCustomers(String tenantId) {
        TenantContext.setCurrentTenant(tenantId);
        try {
            return multiTenantMongoTemplate.getMongoTemplate(tenantId).findAll(Customer.class);
        }
        finally {
            TenantContext.clear();
        }
    }

    public Customer addCustomer(String tenantId, Customer customer) {
        TenantContext.setCurrentTenant(tenantId);
        System.out.println("tenant in service-------- "+ tenantId);
        try {
            customer.setTenant(tenantId);
            System.out.println("tenant info in service-------- " + customer.toString());
            return multiTenantMongoTemplate.getMongoTemplate(tenantId).save(customer);
        }
        finally {
            TenantContext.clear();
        }
    }
}