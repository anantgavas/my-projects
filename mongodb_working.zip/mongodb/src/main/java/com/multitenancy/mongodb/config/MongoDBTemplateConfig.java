package com.multitenancy.mongodb.config;

import com.mongodb.client.MongoClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.CollectionOptions;
import org.springframework.data.mongodb.core.MongoTemplate;

@Configuration
public class MongoDBTemplateConfig {

    @Bean(name = "tenant1MongoTemplate")
    public MongoTemplate tenant1MongoTemplate(MongoClient mongoClient) {
        MongoTemplate mongoTemplate = new MongoTemplate(mongoClient, "tenant1_db");
        createCollectionsIfNotExist(mongoTemplate);
        return mongoTemplate;
    }

    @Bean(name = "tenant2MongoTemplate")
    public MongoTemplate tenant2MongoTemplate(MongoClient mongoClient) {
        MongoTemplate mongoTemplate = new MongoTemplate(mongoClient, "tenant2_db");
        createCollectionsIfNotExist(mongoTemplate);
        return mongoTemplate;
    }

    @Primary
    @Bean(name = "mongoTemplate")
    public MongoTemplate defaultMongoTemplate(MongoClient mongoClient) {
        MongoTemplate mongoTemplate = new MongoTemplate(mongoClient, "default_db");
        createCollectionsIfNotExist(mongoTemplate);
        return mongoTemplate;
    }

    private void createCollectionsIfNotExist(MongoTemplate mongoTemplate) {
        if (!mongoTemplate.collectionExists("customers")) {
            mongoTemplate.createCollection("customers", CollectionOptions.empty());
        }
        // Add more collections as needed
    }
}